package edu.ap.rest;

import org.restlet.Restlet;
import org.restlet.Application;
import org.restlet.resource.Directory;
import org.restlet.routing.Router;
import org.restlet.service.*;

public class QuotesApplication extends Application {
	
	public static final String ROOT_URI = "file:///c:/Users/Steven/Documents/workspace/Oscar_Wilde_Quotes";
	
	@Override
    public synchronized Restlet createInboundRoot() {
    	
    	return new Direcotory(getContext(), ROOT_URI);
        
    }
	
	

}
