package edu.ap.rest;

import org.restlet.Component;
import org.restlet.data.Protocol;

public class QuotesServer {
	
	public static void main(String[] args) {
		
		try {
			
			// Create a new Component.
		    Component component = new Component();
	
		    component.getClients().add(Protocol.FILE);
	
		    // Attach the sample application.
		    component.getDefaultHost().attach(new QuotesApplication());
			component.start();
		} 
	    catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}
