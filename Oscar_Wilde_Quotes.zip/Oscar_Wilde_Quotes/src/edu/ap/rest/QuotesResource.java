package edu.ap.rest;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import org.restlet.resource.*;
import org.restlet.representation.*;

public class QuotesResource extends ServerResource {
	
	public static final String ROOT_URI = "file:///c:/Users/Steven/Documents/workspace/Oscar_Wilde_Quotes";
	
	@Get
	public String[] getAllQuotes() {
		
		ClientResource resource = new ClientResource(ROOT_URI);
		
		
		
	}
	
	
}
