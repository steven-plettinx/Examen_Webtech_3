package edu.ap.rest;

public class QuotesDirectory {

}
