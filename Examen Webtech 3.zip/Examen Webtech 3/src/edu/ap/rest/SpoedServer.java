package edu.ap.rest;

import org.restlet.*;
import org.restlet.data.Protocol;

public class SpoedServer {

	public static void main(String[] args) {
		
		try {
			
			// Create a new Component.
		    Component component = new Component();
	
		    component.getServers().add(Protocol.FILE);
	
		    // Attach the sample application.
		    component.getDefaultHost().attach(new SpoedApplication());
			component.start();
		} 
	    catch (Exception e) {
			System.out.println(e.getMessage());
		}
	}
}

