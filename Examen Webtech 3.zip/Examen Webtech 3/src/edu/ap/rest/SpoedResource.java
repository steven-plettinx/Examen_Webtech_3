package edu.ap.rest;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import org.restlet.resource.*;
import org.restlet.representation.*;


public class SpoedResource extends ServerResource {
	
	@Get
	public String allPatients() {
		
		ClienResource cr = new ClientResource("file:///c:/Users/Steven/Documents/AP/SpoedFiles");
		Representation rep = cr.get();
		String fileContent = rep.getText();
 
		
		
		JSONObject json = new JSONObject();
		json.put("operation", "selectAll");
		json.put("length", resultArray.size());
		JSONArray jsonArray = new JSONArray();
		
		int i = 0;
		for(String s : resultArray) {
			JSONObject obj = new JSONObject();
			obj.put("" + i, s);
			jsonArray.put(obj);
			i++;
		}
		
		json.put("result", jsonArray);

		return json.toString();
	}
	
	@Post("txt")
	public void newPatient(String json) {
		
		JSONObject newPatient = new JSONObject(json);
		String dateTimeIntervention = newPatient.getString("dateTimeIntervention");
		String namePatient = newPatient.getString("namePatient");
		String dateOfBirth = newPatient.getString("dateOfBirth");
		String nameNurse = newPatient.getString("nameNurse");
		
				
	}

}
