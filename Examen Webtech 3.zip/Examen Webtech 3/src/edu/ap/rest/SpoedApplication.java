package edu.ap.rest;

import org.restlet.Application;
import org.restlet.Restlet;
import org.restlet.resource.Directory;

public class SpoedApplication extends Application {
	
	public static final String ROOT_URI = "file:///c:/Users/Steven/Documents/AP/SpoedFiles";
	
	@Override
    public synchronized Restlet createInboundRoot() {
    	
        return new Directory(getContext(), ROOT_URI);
    }

}
